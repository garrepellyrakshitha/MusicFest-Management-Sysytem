# Music Event Management System

## Commands

- npm install
- npm run dev

## Credentials

### Admin

- Email: `admin@app.com`
- Password: `password`

### Participant

- Email: `participant@app.com`
- Password: `password`

### Organizer

- Email: `organizer@app.com`
- Password: `password`

## Pending Tasks

- [ ] Revamp UI
