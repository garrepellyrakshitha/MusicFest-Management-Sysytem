const appConfig = {
	name: 'Music Event Management System',
	logo: '/logo.png',
	cardsLimit: 4,
}

export default appConfig
