import {PlusIcon} from '@heroicons/react/24/solid'
import {
	Alert,
	Badge,
	Button,
	Modal,
	NumberInput,
	Select,
	TextInput,
} from '@mantine/core'
import {DatePicker, TimeInput} from '@mantine/dates'
import {useDisclosure} from '@mantine/hooks'
import type {Venue} from '@prisma/client'
import {EventStatus} from '@prisma/client'
import type {ActionFunction} from '@remix-run/node'
import {json} from '@remix-run/node'
import {Form, useFetcher} from '@remix-run/react'
import * as React from 'react'
import slugify from 'slugify'
import {z} from 'zod'
import {TailwindContainer} from '~/components/TailwindContainer'
import {db} from '~/db.server'
import {requireUserId} from '~/session.server'
import {useOrganizerData} from '~/utils/hooks'
import {
	eventStatusColorLookup,
	formatCurrency,
	formatDate,
	formatTime,
} from '~/utils/misc'
import {badRequest} from '~/utils/misc.server'
import type {inferErrors} from '~/utils/validation'
import {validateAction} from '~/utils/validation'

const AddEventSchema = z.object({
	name: z.string().min(1, 'Name is required'),
	start: z.string().min(1, 'Start date is required'),
	end: z.string().min(1, 'Start time is required'),
	price: z.string().min(1, 'Price is required'),
	venueId: z.string().min(1, 'Venue is required'),
})

interface ActionData {
	success: boolean
	fieldErrors?: inferErrors<typeof AddEventSchema>
}

export const action: ActionFunction = async ({request}) => {
	const organizerId = await requireUserId(request)
	const {fields, fieldErrors} = await validateAction(request, AddEventSchema)

	if (fieldErrors) {
		return badRequest<ActionData>({success: false, fieldErrors})
	}

	await db.event.create({
		data: {
			name: fields.name,
			start: fields.start,
			end: fields.end,
			price: parseInt(fields.price, 10),
			venueId: fields.venueId,
			organizerId,
			slug: slugify(fields.name, {lower: true, strict: true}),
		},
	})

	return json({success: true})
}

const combineDateAndTime = (date: Date, time: Date) => {
	const combined = new Date(date.getTime())
	combined.setHours(time.getHours())
	combined.setMinutes(time.getMinutes())
	combined.setSeconds(time.getSeconds())
	combined.setMilliseconds(time.getMilliseconds())
	return combined
}

export default function ManageEvent() {
	const fetcher = useFetcher<ActionData>()
	const {events, venues} = useOrganizerData()

	const [startDate, setStartDate] = React.useState<Date | null>(null)
	const [startTime, setStartTime] = React.useState<Date | null>(null)
	const [endDate, setEndDate] = React.useState<Date | null>(null)
	const [endTime, setEndTime] = React.useState<Date | null>(null)
	const [venueId, setVenueId] = React.useState<Venue['id'] | null>(null)
	const [enabled, setEnabled] = React.useState(false)
	const [error, setError] = React.useState<string | null>(null)

	const [isModalOpen, handleModal] = useDisclosure(false, {
		onClose: () => {
			setVenueId(null)
			setStartDate(null)
			setStartTime(null)
			setEndDate(null)
			setEndTime(null)
			setEnabled(false)
			setError(null)
		},
	})

	const isSubmitting = fetcher.state !== 'idle'

	React.useEffect(() => {
		if (fetcher.state !== 'idle' && fetcher.submission === undefined) {
			return
		}

		if (fetcher.data?.success) {
			handleModal.close()
		}
		// handleModal is not meemoized, so we don't need to add it to the dependency array
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [fetcher.data?.success, fetcher.state, fetcher.submission])

	React.useEffect(() => {
		if (!startDate || !startTime || !endDate || !endTime) {
			setEnabled(false)
			return
		}

		const start = combineDateAndTime(startDate, startTime)
		const end = combineDateAndTime(endDate, endTime)

		if (start >= end) {
			setError('Start date must be before end date')
			setEnabled(false)
			return
		} else {
			setError(null)
		}

		if (!venueId) return

		const venueEvents = events.filter(
			event =>
				event.venueId === venueId && event.status !== EventStatus.CANCELLED
		)
		const timeConflict = venueEvents.some(event => {
			const eventStart = new Date(event.start)
			const eventEnd = new Date(event.end)

			const start = combineDateAndTime(startDate, startTime)
			const end = combineDateAndTime(endDate, endTime)

			return (
				(start >= eventStart && start <= eventEnd) ||
				(end >= eventStart && end <= eventEnd) ||
				(start <= eventStart && end >= eventEnd)
			)
		})

		if (timeConflict) {
			setError(
				'This venue is not available for the selected date and time. Please select a different date and time.'
			)
			setEnabled(false)
		} else {
			setError(null)
			setEnabled(true)
		}
	}, [venueId, startDate, startTime, endDate, endTime, events])

	const createEvent = (e: React.FormEvent<HTMLFormElement>) => {
		e.preventDefault()

		if (!startDate || !startTime || !endDate || !endTime || !venueId) return

		const formData = new FormData(e.currentTarget)

		const start = combineDateAndTime(startDate!, startTime!)
		const end = combineDateAndTime(endDate!, endTime!)

		formData.append('start', start.toISOString())
		formData.append('end', end.toISOString())

		fetcher.submit(formData, {
			method: 'post',
			replace: true,
		})
	}

	return (
		<>
			<TailwindContainer className="rounded-md bg-white">
				<div className="mt-8 px-4 py-10 sm:px-6 lg:px-8">
					<div className="sm:flex sm:flex-auto sm:items-center sm:justify-between">
						<div>
							<h1 className="text-3xl font-semibold text-gray-900">
								Manage Events
							</h1>
							<p className="mt-2 text-sm text-gray-700">
								A list of all the events you have created.
							</p>
						</div>
						<div>
							<Button
								loading={isSubmitting}
								loaderPosition="left"
								onClick={() => handleModal.open()}
							>
								<PlusIcon className="h-4 w-4" />
								<span className="ml-2">Add event</span>
							</Button>
						</div>
					</div>
					<div className="mt-8 flex flex-col">
						<div className="-my-2 -mx-4 overflow-x-auto sm:-mx-6 lg:-mx-8">
							<div className="inline-block min-w-full py-2 align-middle md:px-6 lg:px-8">
								<table className="min-w-full divide-y divide-gray-300">
									<thead>
										<tr>
											<th
												scope="col"
												className="py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-gray-900 sm:pl-6 md:pl-0"
											>
												Name
											</th>

											<th
												scope="col"
												className="py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-gray-900 sm:pl-6 md:pl-0"
											>
												Time
											</th>
											<th
												scope="col"
												className="py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-gray-900 sm:pl-6 md:pl-0"
											>
												Price
											</th>
											<th
												scope="col"
												className="py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-gray-900 sm:pl-6 md:pl-0"
											>
												Venue
											</th>
											<th
												scope="col"
												className="py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-gray-900 sm:pl-6 md:pl-0"
											>
												Status
											</th>
											<th
												scope="col"
												className="relative py-3.5 pl-3 pr-4 sm:pr-6 md:pr-0"
											></th>
										</tr>
									</thead>

									<tbody className="divide-y divide-gray-200">
										{events.map(event => (
											<tr key={event.id}>
												<td className="whitespace-nowrap py-4 pl-4 pr-3 text-sm font-medium text-gray-900 sm:pl-6 md:pl-0">
													{event.name}
												</td>
												<td className="whitespace-nowrap py-4 pl-4 pr-3 text-sm font-medium text-gray-900 sm:pl-6 md:pl-0">
													<div className="flex items-center">
														<div>
															<p>{formatDate(event.start)}</p>
															<p className="text-gray-500">
																{formatTime(event.start)}
															</p>
														</div>
														<span className="px-2">-</span>
														<div>
															<p>{formatDate(event.end)}</p>
															<p className="text-gray-500">
																{formatTime(event.end)}
															</p>
														</div>
													</div>
												</td>
												<td className="whitespace-nowrap py-4 pl-4 pr-3 text-sm font-medium text-gray-900 sm:pl-6 md:pl-0">
													{formatCurrency(event.price)}
												</td>
												<td className="whitespace-nowrap py-4 pl-4 pr-3 text-sm font-medium text-gray-900 sm:pl-6 md:pl-0">
													<p>{event.venue.name}</p>
													<p className="text-gray-500">{event.venue.address}</p>
												</td>
												<td className="whitespace-nowrap py-4 pl-4 pr-3 text-sm font-medium text-gray-900 sm:pl-6 md:pl-0">
													<Badge color={eventStatusColorLookup(event.status)}>
														{event.status}
													</Badge>
												</td>
												<td className="relative space-x-4 whitespace-nowrap py-4 pl-3 pr-4 text-left text-sm font-medium sm:pr-6 md:pr-0">
													<div className="flex items-center gap-6">
														<Button
															loading={isSubmitting}
															variant="subtle"
															loaderPosition="right"
															color="red"
															compact
															disabled={event.status === EventStatus.CANCELLED}
															onClick={() => {
																fetcher.submit(
																	{
																		eventId: event.id,
																	},
																	{
																		action: '/api/events/delete',
																		method: 'post',
																		replace: true,
																	}
																)
															}}
														>
															Cancel
														</Button>
													</div>
												</td>
											</tr>
										))}
									</tbody>
								</table>
							</div>
						</div>
					</div>
				</div>
			</TailwindContainer>

			<Modal
				opened={isModalOpen}
				onClose={() => handleModal.close()}
				title="Add event"
				centered
				overlayBlur={1.2}
				overlayOpacity={0.6}
			>
				<Form onSubmit={createEvent}>
					{error && <Alert color="red">{error}</Alert>}

					<fieldset disabled={isSubmitting} className="flex flex-col gap-4">
						<TextInput
							name="name"
							label="Name"
							error={fetcher.data?.fieldErrors?.name}
							required
						/>
						<div className="grid grid-cols-2 gap-4">
							<DatePicker
								label="Start Date"
								value={startDate}
								onChange={date => setStartDate(date)}
								minDate={new Date(new Date().setDate(new Date().getDate() + 1))}
								required
							/>

							<TimeInput
								label="Start Time"
								format="12"
								value={startTime}
								onChange={time => setStartTime(time)}
								required
							/>
						</div>

						<div className="grid grid-cols-2 gap-4">
							<DatePicker
								label="End Date"
								value={endDate}
								onChange={date => setEndDate(date)}
								minDate={new Date(new Date().setDate(new Date().getDate() + 1))}
								required
							/>

							<TimeInput
								label="End Time"
								format="12"
								value={endTime}
								onChange={time => setEndTime(time)}
								required
							/>
						</div>

						<NumberInput
							name="price"
							label="Price"
							icon="$"
							error={fetcher.data?.fieldErrors?.price}
							required
						/>

						<Select
							name="venueId"
							label="Venue"
							value={venueId}
							onChange={id => setVenueId(id)}
							error={fetcher.data?.fieldErrors?.venueId || Boolean(error)}
							data={venues.map(venue => ({
								value: venue.id,
								label: venue.name,
							}))}
							required
						/>

						<div className="mt-1 flex items-center justify-end gap-4">
							<Button
								variant="subtle"
								disabled={isSubmitting}
								onClick={() => handleModal.close()}
								color="red"
							>
								Cancel
							</Button>
							<Button
								type="submit"
								variant="default"
								disabled={!enabled}
								loading={isSubmitting}
								loaderPosition="right"
							>
								Add event
							</Button>
						</div>
					</fieldset>
				</Form>
			</Modal>
		</>
	)
}
